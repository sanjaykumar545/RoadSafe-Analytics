import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, accuracy_score
import joblib
import os

def train_and_save_model():
    """
    Train a Decision Tree model on the Iris dataset and save it.
    """
    print("Loading Iris dataset...")
    iris = load_iris()
    X = iris.data
    y = iris.target
    feature_names = iris.feature_names
    target_names = iris.target_names

    # DataFrame for saving dataset
    df = pd.DataFrame(X, columns=feature_names)
    df['target'] = y
    df['target_name'] = [target_names[i] for i in y]

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Train Decision Tree
    print("\nTraining Decision Tree model...")
    dt_model = DecisionTreeClassifier(criterion="entropy", max_depth=4, random_state=42)
    dt_model.fit(X_train, y_train)

    # Evaluate
    preds = dt_model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print(f"Decision Tree Accuracy: {acc:.4f}")
    print("Classification Report:")
    print(classification_report(y_test, preds, target_names=target_names))

    # Ensure models/ directory exists
    os.makedirs('models', exist_ok=True)

    # Save model
    joblib.dump(dt_model, 'models/decision_tree_model.pkl')

    # Save dataset info
    dataset_info = {
        'feature_names': list(feature_names),
        'target_names': list(target_names),
        'feature_ranges': {
            name: {'min': float(df[name].min()), 'max': float(df[name].max())}
            for name in feature_names
        }
    }
    joblib.dump(dataset_info, 'models/dataset_info.pkl')

    # Save dataset for exploration
    df.to_csv('models/iris_dataset.csv', index=False)

    print("\nFiles created inside /models:")
    print("- decision_tree_model.pkl")
    print("- dataset_info.pkl")
    print("- iris_dataset.csv")

    return dt_model, dataset_info

if __name__ == "__main__":
    train_and_save_model()
