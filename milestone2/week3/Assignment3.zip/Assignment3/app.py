import streamlit as st
import pandas as pd
import numpy as np
import joblib
import plotly.express as px
from sklearn import tree
import matplotlib.pyplot as plt

# Page configuration
st.set_page_config(
    page_title="🌸 Iris Decision Tree App",
    page_icon="🌸",
    layout="wide",
    initial_sidebar_state="expanded"
)

@st.cache_data
def load_data():
    try:
        df = pd.read_csv('models/iris_dataset.csv')
        dataset_info = joblib.load('models/dataset_info.pkl')
        return df, dataset_info
    except FileNotFoundError:
        st.error("🚨 Files not found! Run train_model.py first.")
        st.stop()

@st.cache_resource
def load_model():
    try:
        model = joblib.load('models/decision_tree_model.pkl')
        return model
    except FileNotFoundError:
        st.error("🚨 Model not found! Run train_model.py first.")
        st.stop()

def create_feature_inputs(dataset_info):
    st.markdown("### 🔧 Input Features")
    features = {}
    feature_names = dataset_info['feature_names']
    feature_ranges = dataset_info['feature_ranges']

    col1, col2 = st.columns(2)
    for i, feat in enumerate(feature_names):
        col = col1 if i % 2 == 0 else col2
        features[feat] = col.slider(
            f"{feat}",
            min_value=feature_ranges[feat]['min'],
            max_value=feature_ranges[feat]['max'],
            value=(feature_ranges[feat]['min'] + feature_ranges[feat]['max']) / 2,
            step=0.1,
        )
    return features

def make_prediction(features, model, dataset_info):
    feature_array = np.array([[features[name] for name in dataset_info['feature_names']]])
    pred = model.predict(feature_array)[0]
    proba = model.predict_proba(feature_array)[0]
    target_names = dataset_info['target_names']
    return target_names[pred], proba, target_names

def main():
    st.title("🌸 Iris Classification with Decision Tree")

    df, dataset_info = load_data()
    model = load_model()

    st.sidebar.markdown("## 🚀 Navigation")
    app_mode = st.sidebar.selectbox(
        "Choose mode:",
        ["🎯 Prediction Mode", "📊 Data Exploration", "🌳 Decision Tree Visualization", "ℹ️ About"]
    )

    if app_mode == "🎯 Prediction Mode":
        features = create_feature_inputs(dataset_info)
        if st.button("🔮 Predict"):
            pred, proba, target_names = make_prediction(features, model, dataset_info)
            st.success(f"🌸 Predicted Species: **{pred}**")
            proba_df = pd.DataFrame({"Species": target_names, "Probability": proba})
            st.bar_chart(proba_df.set_index("Species"))

    elif app_mode == "📊 Data Exploration":
        st.write("### Dataset Overview")
        st.dataframe(df.head())
        st.write("### Statistical Summary")
        st.write(df.describe())
        feature_cols = dataset_info['feature_names']
        feature = st.selectbox("Choose feature for histogram:", feature_cols)
        fig = px.histogram(df, x=feature, color="target_name", title=f"Distribution of {feature}")
        st.plotly_chart(fig)

    elif app_mode == "🌳 Decision Tree Visualization":
        st.write("### Decision Tree Structure")
        fig, ax = plt.subplots(figsize=(12, 6))
        tree.plot_tree(
            model,
            feature_names=dataset_info['feature_names'],
            class_names=dataset_info['target_names'],
            filled=True
        )
        st.pyplot(fig)

    elif app_mode == "ℹ️ About":
        st.write("""
        ### About this app
        - Dataset: Iris flowers (150 samples, 3 species, 4 features).
        - Model: Decision Tree Classifier (entropy, max_depth=4).
        - Features: Sepal length/width, Petal length/width.
        - Modes:
          - 🎯 Prediction Mode
          - 📊 Data Exploration
          - 🌳 Decision Tree Visualization
        """)

if __name__ == "__main__":
    main()
